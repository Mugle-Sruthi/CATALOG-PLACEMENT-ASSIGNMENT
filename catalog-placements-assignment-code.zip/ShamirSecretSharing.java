import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

public class ShamirSecretSharing {
    
    public static void main(String[] args) throws IOException {
        String json1 = readFile("path/to/testcase1.json");
        String json2 = readFile("path/to/testcase2.json");

        long secret1 = findSecretConstant(json1);
        long secret2 = findSecretConstant(json2);

        System.out.println("Secret for first test case: " + secret1);
        System.out.println("Secret for second test case: " + secret2);
    }

    private static String readFile(String filePath) throws IOException {
        FileReader fileReader = new FileReader(filePath);
        StringBuilder stringBuilder = new StringBuilder();
        int i;
        while ((i = fileReader.read()) != -1) {
            stringBuilder.append((char) i);
        }
        fileReader.close();
        return stringBuilder.toString();
    }

    private static long findSecretConstant(String jsonString) {
        Map<Integer, Long> points = new HashMap<>();
        String keysString = jsonString.substring(jsonString.indexOf("\"keys\":") + 8, jsonString.indexOf("}", jsonString.indexOf("\"keys\":")) + 1);
        int k = Integer.parseInt(keysString.substring(keysString.indexOf("\"k\":") + 5, keysString.indexOf(",", keysString.indexOf("\"k\":"))).trim());

        int rootCount = 1;
        while (jsonString.contains("\"" + rootCount + "\":")) {
            String rootSection = jsonString.substring(jsonString.indexOf("\"" + rootCount + "\":") + 5, jsonString.indexOf("}", jsonString.indexOf("\"" + rootCount + "\":")) + 1);
            String baseStr = rootSection.substring(rootSection.indexOf("\"base\":") + 8, rootSection.indexOf(",", rootSection.indexOf("\"base\":"))).trim();
            String valueStr = rootSection.substring(rootSection.indexOf("\"value\":") + 9, rootSection.indexOf("\"", rootSection.indexOf("\"value\":") + 9)).trim();

            int base = Integer.parseInt(baseStr);
            long decodedValue = Long.parseLong(valueStr, base);

            points.put(rootCount, decodedValue);
            rootCount++;
        }

        // Apply Lagrange Interpolation to find the constant term (c).
        long constantTerm = 0;
        for (int i : points.keySet()) {
            long term = points.get(i);
            for (int j : points.keySet()) {
                if (i != j) {
                    term *= j / (double) (j - i);
                }
            }
            constantTerm += term;
        }

        return constantTerm;
    }
}
